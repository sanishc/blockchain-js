import dotenv from "dotenv";
import { socketHandlers } from "./services";
import { createServer } from "http";
import { Server } from "socket.io";

const httpServer = createServer();
const io = new Server(httpServer, { cors: { origin: "*" } });

dotenv.config();

io.on("connection", (socket) => {
  socketHandlers.ConnectionHandler(io, socket);
  socketHandlers.ActionHandler(socket);
  socketHandlers.EventHandler(socket);
});

httpServer.listen(process.env.PORT, () => {
  console.log(`server listening on PORT: ${process.env.PORT}`);
});
